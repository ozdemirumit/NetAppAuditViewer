# Tail reliability tests

These two scripts exercise the `TailReader` class against a range of
real-world file-rotation and write-pattern scenarios. They are standalone
Python scripts (no pytest/unittest framework needed) and rely only on the
standard library.

Run them from the repo root:

```bash
python tests/test_tail_basic.py
python tests/test_tail_hard.py
```

## What they cover

### `test_tail_basic.py` (6 scenarios)

1. **Byte-by-byte writes** — events written one byte at a time to the file,
   simulating slow network-mounted storage.
2. **Fast concurrent writes** — 100 events flushed as fast as possible to
   catch races between the writer and the tail reader.
3. **Rotation during a partial event** — a half-written event exists in the
   buffer when the file is rotated; rotation must be detected and the stale
   buffer discarded.
4. **Malformed event handling** — garbage XML between valid events must be
   skipped without losing the valid ones.
5. **Unlink + recreate** — the file is deleted and then recreated; tail
   must recover and pick up new events.
6. **`start_at_end` mode** — used by folder-load; existing content must not
   be replayed, but subsequent appends must still be captured.

### `test_tail_hard.py` (4 scenarios)

A. **5000 events at high write rate** — no drops, no duplicates.
B. **5 in-place rotations** — file is repeatedly opened in `wb` mode with
   new generations of events; each rotation must be detected.
C. **Random-chunk-size writes** — 500 events dribbled in variable-size
   chunks; final output must be exactly 500 unique events.
D. **Rename-based rotation** — file is renamed aside and a fresh empty file
   is created at the original path; tail must follow the new file.

All scenarios should report `PASS`. If any fails on your system,
the most likely cause is filesystem behaviour that differs from the
POSIX assumptions (notably older network filesystems that don't update
inode numbers on recreate — please open an issue with your environment).
